package vehicle;

public enum FuelType {
    PETROL,
    DIESEL,
    ELECTRIC,
    HYBRID
}

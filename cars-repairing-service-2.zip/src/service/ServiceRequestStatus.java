package service;

public enum ServiceRequestStatus {
    NEW,
    IN_PROGRESS,
    READY,
    CLOSED
}

package service;

public enum RateType {
    HOURLY,
    SALARY
}
